package ir.emergencyconnect;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;

public class MainActivity extends Activity {
    LinearLayout root;
    TextView status;

    int navy = Color.rgb(16,42,67);
    int teal = Color.rgb(22,125,101);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(navy);
        getWindow().setNavigationBarColor(navy);
        build();
        refreshStatus();
    }

    GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius);
        return d;
    }

    TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.RIGHT);
        t.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        t.setPadding(4, 8, 4, 8);
        return t;
    }

    void build() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(20, 20, 20, 24); root.setBackgroundColor(Color.rgb(245,248,250));
        scroll.addView(root); setContentView(scroll);

        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL); hero.setPadding(20,22,20,22);
        hero.setBackground(bg(navy, 28));
        TextView title = text("همراه اضطراری", 27, Color.WHITE, true);
        TextView sub = text("مرکز آمادگی ارتباطی و اطلاعات آفلاین", 14, Color.rgb(210,225,235), false);
        hero.addView(title); hero.addView(sub);
        root.addView(hero);

        status = text("در حال بررسی وضعیت شبکه…", 16, navy, true);
        status.setPadding(4,20,4,12); root.addView(status);
        button("بررسی دوباره اینترنت", "وضعیت شبکه گوشی بررسی شد.", this::refreshStatus);
        heading("ابزارهای اتصال رایگان");
        paragraph("این برنامه ابزارهای رسمی را معرفی می‌کند؛ اتصال خودکار یا تضمین عبور از محدودیت‌ها ندارد. در زمان قطع کامل اینترنت بین‌الملل، VPN کار نمی‌کند.");
        button("Psiphon – وب‌سایت رسمی", null, () -> open("https://psiphon.ca/"));
        button("Tor Browser – وب‌سایت رسمی", null, () -> open("https://www.torproject.org/download/"));
        button("Lantern – وب‌سایت رسمی", null, () -> open("https://lantern.io/"));
        button("Briar – پیام‌رسانی محلی", null, () -> open("https://briarproject.org/"));

        heading("ارتباط و آمادگی آفلاین");
        paragraph("شماره‌های ضروری و اطلاعات خانواده را در دفترچه تلفن گوشی ذخیره کن. تماس عادی فقط در صورت فعال بودن شبکه تلفن همراه ممکن است.");
        button("باز کردن شماره‌گیر", null, () -> {
            Intent i = new Intent(Intent.ACTION_DIAL);
            startActivity(i);
        });
        button("ارسال پیامک اضطراری", null, () -> {
            Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:"));
            i.putExtra("sms_body", "من در حال حاضر در امنیت هستم. لطفاً وضعیت خودت را اطلاع بده.");
            startActivity(i);
        });

        heading("نکات ایمنی");
        paragraph("• برنامه‌ها را فقط از وب‌سایت رسمی یا فروشگاه معتبر دریافت کن.\n• فایل‌های VPN ناشناس و پروفایل‌های ارسالی افراد ناشناس را نصب نکن.\n• نقشه منطقه و شماره‌های مهم را پیش از اختلال اینترنت ذخیره کن.\n• برای ارتباط بدون اینترنت، اعضای خانواده باید از قبل یک پیام‌رسان محلی سازگار را نصب و آزمایش کرده باشند.");
        TextView footer = text("نسخه آزمایشی ۱.۰  |  همراه اضطراری", 12, Color.GRAY, false);
        footer.setGravity(Gravity.CENTER); root.addView(footer);
    }

    void heading(String s) {
        TextView t = text(s, 19, navy, true);
        t.setPadding(2,22,2,6); root.addView(t);
    }
    void paragraph(String s) {
        TextView t = text(s, 14, Color.rgb(65,78,90), false);
        t.setBackground(bg(Color.WHITE, 18)); t.setPadding(16,14,16,14);
        root.addView(t);
        LinearLayout.LayoutParams p = (LinearLayout.LayoutParams)t.getLayoutParams();
        p.bottomMargin = 8; t.setLayoutParams(p);
    }
    void button(String label, String toast, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setTextColor(Color.WHITE);
        b.setAllCaps(false); b.setTextSize(15); b.setBackground(bg(teal, 18));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0,6,0,6); b.setLayoutParams(p);
        b.setOnClickListener(v -> { if(toast != null) Toast.makeText(this, toast, Toast.LENGTH_SHORT).show(); action.run(); });
        root.addView(b);
    }
    void open(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch(Exception e) { Toast.makeText(this, "مرورگر در دسترس نیست", Toast.LENGTH_SHORT).show(); }
    }
    void refreshStatus() {
        ConnectivityManager cm = (ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
        Network n = cm.getActiveNetwork();
        NetworkCapabilities c = n == null ? null : cm.getNetworkCapabilities(n);
        boolean connected = c != null && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
        boolean validated = c != null && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
        String s = !connected ? "اتصال شبکه پیدا نشد؛ برنامه همچنان به اطلاعات آفلاین دسترسی دارد."
                : validated ? "شبکه متصل است؛ دسترسی واقعی اینترنت توسط اندروید تأیید شده."
                : "شبکه شناسایی شد، اما دسترسی کامل به اینترنت تأیید نشده است.";
        status.setText("وضعیت ارتباط\n" + s);
    }
}
